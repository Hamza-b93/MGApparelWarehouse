import {
  Column,
  CreateDateColumn,
  Entity,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';

@Entity({
  schema: 'Essentials',
  name: 'Users',
})
export class User {
  @PrimaryGeneratedColumn()
  UserId: number;

  @CreateDateColumn({
    type: 'datetime',
  })
  CreatedAt: Date;

  @UpdateDateColumn({
    type: 'datetime',
  })
  UpdatedAt: Date;

  @Column({
    type: 'nvarchar',
    length: 16,
  })
  UserName: string;

  @Column({
    type: 'nvarchar',
    length: 8,
  })
  UserPassword: string;
}
