import {
  Column,
  CreateDateColumn,
  Entity,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';

@Entity({
  schema: 'Data',
  name: 'Allocations',
})
export class Allocation {
  @PrimaryGeneratedColumn()
  AllocationId: number;

  @CreateDateColumn({
    type: 'datetime',
  })
  CreatedAt: Date;

  @UpdateDateColumn({
    type: 'datetime',
  })
  UpdatedAt: Date;

  @Column({
    type: 'date',
  })
  UpdatedAtDate: Date;

  @Column({
    type: 'int',
  })
  RollId: number;

  @Column({
    type: 'nvarchar',
    length: 8,
  })
  AllocationStatus: string;

  @Column({
    type: 'nvarchar',
    length: 32,
  })
  AllocatedTo: string;

  @Column({
    type: 'bit',
  })
  IsLatest: number;
}
