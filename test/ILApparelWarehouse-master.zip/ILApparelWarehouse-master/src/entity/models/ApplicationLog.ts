import {
  Column,
  CreateDateColumn,
  Entity,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';

@Entity({
  schema: 'Logging',
  name: 'ApplicationLog',
})
export class ApplicationLog {
  @PrimaryGeneratedColumn()
  AppLogId: number;

  @CreateDateColumn({
    type: 'datetime',
  })
  CreatedAt: Date;

  @UpdateDateColumn({
    type: 'datetime',
  })
  UpdatedAt: Date;

  @Column({
    type: 'nvarchar',
    length: 32,
  })
  RequestIpAddr: string;

  @Column({
    type: 'nvarchar',
    length: 4000,
  })
  RequestBody: string;

  @Column({
    type: 'nvarchar',
    length: 8,
  })
  RequestType: string;

  @Column({
    type: 'nvarchar',
    length: 64,
  })
  RequestApi: string;
}
