import { IsIn, IsOptional } from 'class-validator';
import {
  Column,
  CreateDateColumn,
  Entity,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';

@Entity({
  schema: 'Essentials',
  name: 'Rolls',
})
export class Roll {
  @PrimaryGeneratedColumn()
  RollId: number;

  @CreateDateColumn({
    type: 'datetime',
  })
  CreatedAt: Date;

  @UpdateDateColumn({
    type: 'datetime',
  })
  UpdatedAt: Date;

  @Column({
    type: 'date',
  })
  UpdatedAtDate: Date;

  @Column({
    type: 'decimal',
    precision: 10,
    scale: 4,
  })
  NetWeight: number;

  @Column({
    type: 'int',
  })
  PackingListId: number;

  @Column({
    type: 'int',
  })
  ParentRollId: number;

  @IsIn([0, 1])
  @Column({
    type: 'smallint',
  })
  IsChildRoll: number;

  @Column({
    type: 'int',
  })
  RollStateId: number;

  @Column({
    type: 'bit',
  })
  IsFresh: number;

  @Column({
    type: 'nvarchar',
    length: 16,
  })
  GeneratedAt: string;

  @Column({
    type: 'smallint',
  })
  IsCardAssigned: number;

  @Column({
    type: 'datetime',
  })
  CardAssignmentTimestamp: Date;

  @Column({
    type: 'nvarchar',
    length: 16,
  })
  @IsIn(['WAREHOUSE', 'CUTTING', 'SEWING', 'SAMPLING', 'TRAINING'])
  TransactionAt: string;

  @Column({
    type: 'int',
  })
  LastAllocationId: number;

  @Column({
    type: 'int',
  })
  ActivityId: number;

  @Column({
    type: 'datetime',
  })
  ActivityRollAssignmentTimestamp: Date;

  @Column({
    type: 'nvarchar',
    length: 16,
  })
  RackLocatorBin: string;

  @IsIn([0, 1])
  @Column({
    type: 'bit',
  })
  IsTransactionManual: number;

  @IsOptional()
  @Column({
    type: 'smallint',
  })
  Antenna: number;
}
