import {
  IsIn,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsPositive,
  IsString,
  Length,
  Min,
} from 'class-validator';
import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
} from 'typeorm';

@Entity({
  schema: 'Essentials',
  name: 'PackingList',
})
export class PackingList {
  @PrimaryGeneratedColumn({
    type: 'int',
  })
  PackingListId: number;

  @CreateDateColumn({
    type: 'datetime',
  })
  CreatedAt: Date;

  @UpdateDateColumn({
    type: 'datetime',
  })
  UpdatedAt: Date;

  @IsOptional()
  @Column({
    type: 'date',
  })
  UploadDate: Date;

  @IsNotEmpty()
  @IsNumber()
  @IsPositive()
  @Column({
    type: 'int',
  })
  PackingListCode: number;

  @IsPositive()
  @IsNotEmpty()
  @IsNumber()
  @Column({
    type: 'decimal',
    precision: 10,
    scale: 4,
  })
  UploadedWeight: number;

  @IsString()
  @IsNotEmpty()
  @Length(1, 64)
  @Column({
    type: 'nvarchar',
    length: 64,
  })
  Order: string;

  @IsString()
  @IsOptional()
  @Length(1, 64)
  @Column({
    type: 'nvarchar',
    length: 64,
  })
  FabricContent: string;

  @IsString()
  @IsOptional()
  @Length(1, 128)
  @Column({
    type: 'nvarchar',
    length: 128,
  })
  FabricColor: string;

  @IsString()
  @IsOptional()
  @Length(1, 32)
  @Column({
    type: 'nvarchar',
    length: 32,
  })
  FabricLot: string;

  @IsString()
  @IsOptional()
  @Length(1, 64)
  @Column({
    type: 'nvarchar',
    length: 64,
  })
  FabricType: string;

  @IsNumber()
  @Min(0)
  @IsOptional()
  @Column({
    type: 'decimal',
    precision: 10,
    scale: 4,
  })
  FabricWidth: number;

  @IsNumber()
  @Min(0)
  @IsOptional()
  @Column({
    type: 'decimal',
    precision: 10,
    scale: 4,
  })
  FabricLength: number;

  @IsString()
  @IsOptional()
  @Length(1, 8)
  @Column({
    type: 'nvarchar',
    length: 8,
  })
  Pieces: string;

  @IsString()
  @IsOptional()
  @Length(1, 8)
  @Column({
    type: 'nvarchar',
    length: 8,
  })
  ItemCode: string;

  @IsString()
  @IsOptional()
  @Length(1, 64)
  @Column({
    type: 'nvarchar',
    length: 64,
  })
  ItemDescription: string;

  @IsString()
  @IsOptional()
  @Length(1, 8)
  @Column({
    type: 'nvarchar',
    length: 8,
  })
  Igp: string;

  @IsString()
  @IsOptional()
  @Length(1, 16)
  @Column({
    type: 'nvarchar',
    length: 16,
  })
  IgpDate: string;

  @IsString()
  @IsOptional()
  @Length(1, 64)
  @Column({
    type: 'nvarchar',
    length: 64,
  })
  Customer: string;

  @IsString()
  @IsOptional()
  @Length(1, 32)
  @Column({
    type: 'nvarchar',
    length: 32,
  })
  CustomerCode: string;

  @IsString()
  @IsNotEmpty()
  @Length(1, 32)
  @Column({
    type: 'nvarchar',
    length: 32,
  })
  Dcn: string;

  @IsString()
  @IsOptional()
  @Length(1, 32)
  @Column({
    type: 'nvarchar',
    length: 32,
  })
  YarnSupplier: string;

  @IsString()
  @IsOptional()
  @Length(1, 8)
  @Column({
    type: 'nvarchar',
    length: 8,
  })
  YarnLot: string;

  @IsString()
  @IsOptional()
  @Length(1, 8)
  @Column({
    type: 'nvarchar',
    length: 8,
  })
  Gsm: string;

  @IsString()
  @IsOptional()
  @Length(1, 64)
  @Column({
    type: 'nvarchar',
    length: 64,
  })
  Supplier: string;

  @IsString()
  @IsOptional()
  @Length(1, 16)
  @Column({
    type: 'nvarchar',
    length: 16,
  })
  SupplierLot: string;

  @IsString()
  @IsOptional()
  @Length(1, 16)
  @Column({
    type: 'nvarchar',
    length: 16,
  })
  SupplierRollId: string;

  @IsNumber()
  @IsOptional()
  @Column({
    type: 'int',
  })
  TransactionType: number;

  @IsNumber()
  @IsIn([0, 1])
  @Column({
    type: 'smallint',
  })
  ForSampling: number;
}
