import {
  Column,
  CreateDateColumn,
  Entity,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';

@Entity({
  schema: 'Logging',
  name: 'ErrorsList',
})
export class ErrorsList {
  @PrimaryGeneratedColumn()
  ErrorId: number;

  @CreateDateColumn({
    type: 'datetime',
  })
  CreatedAt: Date;

  @UpdateDateColumn({
    type: 'datetime',
  })
  UpdatedAt: Date;

  @Column({
    type: 'nvarchar',
    length: 32,
  })
  ErrorType: string;

  @Column({
    type: 'int',
  })
  ErrorNumber: number;

  @Column({
    type: 'nvarchar',
    length: 64,
  })
  ErrorMessage: string;
}
