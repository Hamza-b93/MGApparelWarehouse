import { IsIn, IsPositive } from 'class-validator';
import {
  Column,
  CreateDateColumn,
  Entity,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';

@Entity({
  schema: 'Data',
  name: 'Activities',
})
export class Activity {
  @PrimaryGeneratedColumn()
  ActivityId: number;

  @CreateDateColumn({
    type: 'datetime',
  })
  CreatedAt: Date;

  @UpdateDateColumn({
    type: 'datetime',
  })
  UpdatedAt: Date;

  @Column({
    type: 'date',
  })
  UpdatedAtDate: Date;

  @Column({
    type: 'datetime',
  })
  StartTime: Date;

  @Column({
    type: 'datetime',
  })
  EndTime: Date;

  @Column({
    type: 'decimal',
    precision: 10,
    scale: 4,
  })
  @IsPositive()
  SmallWaste: number;

  @Column({
    type: 'decimal',
    precision: 10,
    scale: 4,
  })
  @IsPositive()
  LargeWaste: number;

  @Column({
    type: 'nvarchar',
    length: 8,
  })
  @IsIn(['FIRST', 'SECOND'])
  Shift: string;

  @Column({
    type: 'nvarchar',
    length: 10,
  })
  @IsIn(['PENDING', 'SUBMITTED', 'REJECTED'])
  ActivityStatus: string;
}
